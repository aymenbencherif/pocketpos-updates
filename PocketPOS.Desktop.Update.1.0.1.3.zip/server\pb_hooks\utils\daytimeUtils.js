/// <reference path="../../pb_data/types.d.ts" />s
module.exports = {

    getFormatedDateTime: (date) => {
        const day = String(new Date(date).getDate()).padStart(2, '0');
        const month = String(new Date(date).getMonth() + 1).padStart(2, '0');
        const year = new Date(date).getFullYear();
        return `${day}-${month}-${year}`;
    },

    updateDateTime: ({transaction, daytimeId, amount}) => {
        var rows = transaction.db()
            .newQuery(`UPDATE dayTime SET 
                    amountTheoretically = amountTheoretically + {:amount} 
                    WHERE id = {:daytimeId} AND isClosed = 0`)
            .bind({ amount, daytimeId })
            .execute().rowsAffected();
        if (rows === 0) {

            let message = "";
            try {
                transaction.findRecordById("dayTime", daytimeId);
                message = "DAY_IS_CLOSED";
            }
            catch (ex) {
                message = "DAY_NOT_FOUND";
            }
            throw new BadRequestError(message);
        }
    }
}