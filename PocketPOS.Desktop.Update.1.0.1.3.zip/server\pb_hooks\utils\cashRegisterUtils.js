/// <reference path="../../pb_data/types.d.ts" />s
module.exports = {

    updateCashRegisterBalance: ({ transaction, cashRegisterId, inAmount, outAmount }) => {
        var rows = transaction.db()
            .newQuery(`UPDATE cashRegister SET 
                [in] = [in] + {:inAmount} ,
                [out] = [out] + {:outAmount} ,
                balance = balance + ({:inAmount} - {:outAmount})
                WHERE id = {:cashRegisterId}`)
            .bind({ cashRegisterId, inAmount, outAmount })
            .execute().rowsAffected();
        if (rows === 0)
            throw new BadRequestError("CASH_REGISTER_NOT_FOUND");
    }
}