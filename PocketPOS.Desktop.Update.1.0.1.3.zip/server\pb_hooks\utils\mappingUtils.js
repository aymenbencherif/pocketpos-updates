module.exports = {

    mapDtoToRecord: ({ dto, record }) => {
        for (const key in dto) {
            if (Object.hasOwn(dto, key) && record.get(key) !== undefined) {
                record.set(key, dto[key]);
            }
        }
        return record;
    }
}