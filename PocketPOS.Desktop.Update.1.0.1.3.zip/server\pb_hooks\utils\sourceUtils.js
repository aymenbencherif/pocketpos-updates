module.exports = {
    getSourceFromTableName: (tableName) => {
        switch (tableName) {
            case "sale_delivery":
            case "sale_delivery_detail":
                return "sale";

            case "sale_return":
            case "sale_return_detail":
                return "sale_return";

            case "purchase_reception":
            case "purchase_reception_detail":
                return "purchase";

            case "loss":
                return "loss";
            default:
                throw new Error(`Unknown table name: ${tableName}`);
        }
    }
}