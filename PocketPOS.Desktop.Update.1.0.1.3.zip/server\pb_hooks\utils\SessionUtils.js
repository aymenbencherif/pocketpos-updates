/// <reference path="../../pb_data/types.d.ts" />s
module.exports = {

    updateSession: ({transaction, sessionId, amount}) => {
        var rows = transaction.db()
            .newQuery(`UPDATE session SET 
                    amountTheoretically = amountTheoretically + {:amount} 
                    WHERE id = {:sessionId} AND isClosed = 0`)
            .bind({ amount, sessionId })
            .execute().rowsAffected();
        if (rows === 0) {

            let message = "";
            try {
                transaction.findRecordById("session", sessionId);
                message = "SESSION_IS_CLOSED";
            }
            catch (ex) {
                message = "SESSION_NOT_FOUND";
            }
            throw new BadRequestError(message);
        }
    }
}