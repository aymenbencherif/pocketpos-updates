/// <reference path="../../pb_data/types.d.ts" />s
module.exports = {


    updateStock: (transaction, record, operation) => {

        if (record.get("destockType") === "service")
            return;
        const stockUtils = require(`${__hooks}/utils/stockUtils.js`);
        const sourceUtils = require(`${__hooks}/utils/sourceUtils.js`);

        const source = sourceUtils.getSourceFromTableName(record.tableName());
        const warehouseId = record.get("warehouseId");
        const lotId = record.get("lotId");
        const sourceRef = record.get("id");

        let productId = record.get("productId");
        let quantity = stockUtils.calculateQuantity(record, operation);

        quantity = stockUtils.handleQuantityBySource(source, quantity);

        if (quantity === 0)
            return;

        if (record.get("destockType") === "destockable") {
            stockUtils.executeUpdateQueries({ transaction, productId, warehouseId, lotId, quantity, source, sourceRef, operation });
            return;
        }
        if (record.get("destockType") === "destock_another") {
            productId = record.get("destockProductId");
            quantity = quantity * record.get("destockQuantity");
            stockUtils.executeUpdateQueries({ transaction, productId, warehouseId, lotId, quantity, source, sourceRef, operation });
            return;
        }

        var trackigns = transaction.findRecordsByFilter("productComposingTracking", `source = "${source}" && sourceRef = "${record.get("id")}"`);
        trackigns.forEach(tr => {
            productId = tr.get("productToDestockId");
            quantity = quantity * tr.get("quantity");
            stockUtils.executeUpdateQueries({ transaction, productId, warehouseId, lotId, quantity, source, sourceRef, operation });
        });
    },
    calculateQuantity(record, operation) {
        switch (operation) {
            case "add": return record.get("quantity");
            case "update": return record.get("quantity") - record.original().get("quantity");
            case "delete": return -record.get("quantity");
            default: throw new Error(`Unknown operation: ${operation}`);
        }
    },

    executeUpdateQueries: ({ transaction, productId, warehouseId, lotId, quantity, source, sourceRef, operation }) => {
        // Update product stock
        transaction.db()
            .newQuery(`
                UPDATE product
                SET currentStock = currentStock + {:quantity}
                WHERE id = {:productId};
            `)
            .bind({ quantity, productId })
            .execute();
        console.log("Update product stock executed");

        // Update or insert stock record per warehouse & lot
        transaction.db()
            .newQuery(`
                INSERT INTO stock (productId, warehouseId, lotId, stock)
                VALUES ({:productId}, {:warehouseId}, {:lotId}, {:quantity})
                ON CONFLICT (productId, warehouseId, lotId)
                DO UPDATE SET stock = stock + {:quantity};
            `)
            .bind({ productId, warehouseId, lotId, quantity })
            .execute();

        if (operation == "delete") {
            transaction.db()
                .newQuery(`DELETE FROM productLog WHERE source = {:source} AND sourceRef = {:sourceRef} AND warehouseId = {:warehouseId}`)
                .bind({ productId, warehouseId, lotId, quantity, source, sourceRef })
                .execute();

            transaction.db()
                .newQuery(`DELETE FROM productComposingTracking WHERE source = {:source} AND sourceRef = {:sourceRef}`)
                .bind({ productId, warehouseId, lotId, quantity, source, sourceRef })
                .execute();
        }
        else {

            transaction.db()
                .newQuery(`
                INSERT INTO productLog (source, sourceRef ,productId, warehouseId, lotId, quantity)
                VALUES ({:source} , {:sourceRef} ,{:productId}, {:warehouseId}, {:lotId}, {:quantity})
                ON CONFLICT (source, sourceRef , productId, warehouseId, lotId)
                DO UPDATE SET quantity = quantity + {:quantity};
            `)
                .bind({ productId, warehouseId, lotId, quantity, source, sourceRef })
                .execute();
        }

    },

    executeProductStock: ({ transaction, productId, warehouseId, variationId, lotId, quantity, setQuantityIntial = false }) => {
        // Update product stock
        var rows = transaction.db()
            .newQuery(`
                UPDATE product
                SET currentStock = currentStock + {:quantity}
                WHERE id = {:productId} AND ((SELECT  allowNegativStock FROM settings_general LIMIT 1) = 1 OR ((currentStock + {:quantity}) >= 0));
            `)
            .bind({ quantity, productId })
            .execute().rowsAffected();
        if (rows === 0)
            throw new BadRequestError("STOCK_NEGATIVE_NOT_ALLOWED");
        // transaction.db().newQuery(`INSERT INTO notification (title,message,badge,duration,isRead,userId) SELECT 'Stock Alert' as title, CONCAT('The stock of product with Name ', {:productId}, ' has reached a negative value.') as message, 'warning' as badge, 5000 as duration, 0 as isRead, userId FROM users WHERE role = 'admin'`).bind({ productId }).execute();
        console.log("Update product stock executed");

        // Update or insert stock record per warehouse & lot
        if (setQuantityIntial === true) {
            transaction.db()
                .newQuery(`
                INSERT INTO stock (productId, warehouseId, lotId, variationId, stock, initialStock)
                VALUES ({:productId}, {:warehouseId}, {:lotId}, {:variationId}, {:quantity}, {:quantity})
                ON CONFLICT (productId, warehouseId, lotId, variationId)
                DO UPDATE SET initialStock = initialStock + {:quantity} , stock = stock + {:quantity};
            `)
                .bind({ productId, warehouseId, lotId, variationId, quantity })
                .execute();
        }
        else {
            transaction.db()
                .newQuery(`
                INSERT INTO stock (productId, warehouseId, lotId, variationId, stock)
                VALUES ({:productId}, {:warehouseId}, {:lotId}, {:variationId}, {:quantity})
                ON CONFLICT (productId, warehouseId, lotId, variationId)
                DO UPDATE SET stock = stock + {:quantity};
            `)
                .bind({ productId, warehouseId, lotId, variationId, quantity })
                .execute();
        }
    },
    createProductLog: ({ transaction, source, sourceRef, productId, warehouseId, variationId, lotId, serialNumbers, destockType, quantity, purchasePrice = 0, date }) => {
        var logColloection = transaction.findCollectionByNameOrId(`productLog`);
        var logRecord = new Record(logColloection, {
            "source": source,
            "sourceRef": sourceRef,
            "productId": productId,
            "warehouseId": warehouseId,
            "lotId": lotId,
            "variationId": variationId,
            "quantity": quantity,
            "destockType": destockType,
            "purchasePrice": purchasePrice,
            "serialNumbers": serialNumbers,
            "date": date
        });
        transaction.save(logRecord);
    },

    updateProductLog: ({ transaction, source, sourceRef, productId, variationId, newQuantity, purchasePrice = 0 }) => {

        const productLog = transaction.findRecordsByFilter("productLog", `source="${source}" && sourceRef="${sourceRef}" && productId = "${productId}" && variationId = '${variationId || ''}'`)[0];
        productLog.set("quantity", newQuantity);
        productLog.set("purchasePrice", purchasePrice);
        transaction.save(productLog);
    },

    deleteProductLog: ({ transaction, source, sourceRef, productId }) => {

        transaction.delete(transaction.findRecordsByFilter("productLog", `source="${source}" && sourceRef="${sourceRef}" && productId = "${productId}"`)[0]);
    },

    handleQuantityBySource: (source, quantity) => {
        switch (source) {
            case "sale":
            case "loss":
                return -quantity;
            case "purchase":
            case "sale_return":
                return quantity;
            default:
                throw new Error(`Unknown source: ${source}`);
        }
    }
}