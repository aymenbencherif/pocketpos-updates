module.exports = {
    begin,
    end,
    isSync,
    getSourceNodeId,
    getChangeId,
    applyChange,
    shouldSync,
    getCurrentOriginId,
    stopSync,
    resumSync
    //pushChangesToMaster
}
let context = null;
let originId = null;
let _stopSync = false;
const directExcludedCollections = ["productLog", "stock", "daytimeLog", "sessionLog", "sync_outbox", "walkingCustomerLog", "walkingProviderLog", "transfer", "_superusers", "settings_sync"]
const considerExcludedCollections = ["transfer"]

function stopSync()
{
    _stopSync = true
}
function resumSync()
{
    _stopSync = false;
}
function begin(options) {
    context = {
        isSync: true,
        sourceOriginId: options?.sourceOriginId || null,
        changeId: options?.changeId || null
    };
}
function end() {
    context = null
}
function isSync() {
    return context !== null && context.isSync === true;
}
function getSourceNodeId() {
    return context ? context.sourceOriginId : null
}
function getChangeId() {
    return context ? context.changeId : null
}
function applyChange(transaction, change) {
    if (change.operation === "delete")
        return applyDelete(transaction, change)
    else
        return applyCreateOrUpdate(transaction, change);
}
function getCurrentOriginId(transaction) {
    if (originId === null) {
        const settings = transaction.findCollectionByNameOrId("settings_sync");
        const record = transaction.findFirstRecordByFilter(settings);
        originId = record.get("originId");
    }
    return originId;
}
function shouldSync(collectionName, record) {
    if(_stopSync===false)
        return false;
    if (directExcludedCollections.includes(collectionName) === false)
        return true;
    if (considerExcludedCollections.includes(collectionName) === true) {
        switch (collectionName) {
            case "transfer":
                if (["sale", "sale_return", "purchase"].includes(record.get("source")))
                    return false;
        }
    }
    return false;
}
function applyCreateOrUpdate(transaction, change) {
    const collection = transaction.findCollectionByNameOrId(change.collection);
    let record = null
    try {
        record = transaction.findRecordById(collection, change.recordId);
    }
    catch (err) {
        record = new Record(collection);
        record.set("id", change.recordId);
    }
    const data = change.data;
    for (const key in data) {
        record.set(key, data[key]);
        if (Object.prototype.hasOwnProperty.call(data, key)) {
            continue;
        }
        if (["id", "created", "updated"].includes(key))
            continue;
        console.log(`${key} : ${data[key]}`)
        
    }
    console.log(JSON.stringify(record.publicExport()));
    console.log(JSON.stringify(data));
    transaction.save(record);
    const id = record.get("id");
    return id;
}
function applyDelete(transaction, change) {
    const collection = transaction.findCollectionByNameOrId(change.collection);
    const record = transaction.findRecordById(collection, change.recordId);
    const id = record.get("id");
    transaction.delete(record);
    return id;
}
// function pushChangesToMaster({ app, originId, changes }) {
//     const settingCollection = app.findCollectionByNameOrId('settings_sync');
//     const record = app.findFirstRecordByFilter(settingCollection);
//     if (record.get("masterUrl") === null || record.get("masterUrl") === undefined || record.get("masterUrl") === null)
//     {
//         return [];
//     }
// }
