/// <reference path="../../pb_data/types.d.ts" />
module.exports = {
    getCurrentLocalDate(date) {
        const localDate = new Date(date);
        localDate.setHours(localDate.getHours() + 1);
        return localDate;
    }
}