module.exports = {
    recalculateProduct: ({ transaction, productId }) => {

        const productCollection = transaction.findCollectionByNameOrId("product");
        const productLogCollection = transaction.findCollectionByNameOrId("productLog");
        const stockProductCollection = transaction.findCollectionByNameOrId("stock");
        const purchaseDetailCollection = transaction.findCollectionByNameOrId("purchase_reception_detail");
        const saleDetailCollection = transaction.findCollectionByNameOrId("sale_delivery_detail");
        const saleReturnCollection = transaction.findCollectionByNameOrId("sale_return_detail");
        const lossCollection = transaction.findCollectionByNameOrId("loss");
        const product = transaction.findRecordById(productCollection, productId);
        const productStock = transaction.findRecordsByFilter(stockProductCollection, `productId = '${productId}'`);

        const updateDetail = ({ transaction, recordCollection, currentLog, source, sourceRef, productId, newPMP }) => {
            const docDetail = transaction.findRecordById(recordCollection, sourceRef);
            const destockType = docDetail.get("destockType");
            if (destockType === "destockable") {
                docDetail.set("purchasePrice", newPMP);
                currentLog.set("quantity", docDetail.get("quantity"));
            }

            else {
                const trackingCollection = transaction.findCollectionByNameOrId("productComposingTracking");
                const trackedProduct = transaction.findFirstRecordByFilter(trackingCollection, `source = '${source}' && sourceRef = '${sourceRef}' && productToDestockId = '${productId}'`)
                const quantity = docDetail.get("quantity") * trackedProduct.get("quantity");
                trackedProduct.set("purchasePrice", newPMP);
                transaction.save(trackedProduct);
                let newPurchasePrice = 0;
                const allTrackedProduct = transaction.findRecordsByFilter(trackingCollection, `source = '${source}' && sourceRef = '${sourceRef}'`);
                allTrackedProduct.forEach(element => {
                    newPurchasePrice += element.get("purchasePrice") * element.get("quantity");
                });
                docDetail.set("purchasePrice", newPurchasePrice);
                currentLog.set("quantity", quantity);
            }
            transaction.save(docDetail);
            //transaction.save(currentLog);
        }

        product.set("currentStock", 0);
        product.set("currentCost", 0);
        productStock.forEach(element => {
            element.set("stock", 0);
            element.set("initialStock", 0);
            transaction.save(element);
        });
        transaction.save(product);

        const inventoryDetailCollection = transaction.findCollectionByNameOrId("inventory_detail");
        const logs = transaction.findRecordsByFilter(productLogCollection, `productId = '${productId}'`, 'date').map(m => m.publicExport());
        transaction.db().newQuery(`UPDATE productLog set quantity = 0  WHERE productId = '${productId}'`).execute();
        if (product.get("destockType") !== "destockable") {
            return e.json(200, "OK")
        }
        let stock = 0;
        //let purchasePrice;
        let pmp = 0;
        logs.forEach(element => {
            const source = element.source;
            const quantity = element.quantity;
            const logPurchasePrice = element.purchasePrice;
            const sourceRef = element.sourceRef;
            const currentLog = transaction.findRecordById(productLogCollection, element.id);
            if (source === "initial") {
                currentLog.set("quantity", product.get("initialStock"));
                currentLog.set("purchasePrice", product.get("initialPurchasePrice"));
                currentLog.set("date", new Date(2000, 0, 1));
                console.log("before initial");
                transaction.save(currentLog);
                console.log("initial");
                stock = quantity;

                pmp = product.get("initialCost");
                console.log("Stock after initial : " + stock);
            }
            else if (source === "purchase") {
                const docDetail = transaction.findRecordById(purchaseDetailCollection, element.sourceRef);
                currentLog.set("quantity", docDetail.get("quantity"));
                currentLog.set("purchasePrice", docDetail.get("priceET"));
                transaction.save(docDetail);
                transaction.save(currentLog);
                if (stock + quantity <= 0)
                    pmp = logPurchasePrice;
                else
                    pmp = ((quantity * logPurchasePrice) + (stock * pmp)) / (stock + quantity)
                console.log(pmp);
                stock += quantity;
                console.log("Stock after purchase : " + stock);
            }
            else if (source === "sale") {
                updateDetail({ transaction, recordCollection: saleDetailCollection, currentLog, source, sourceRef: element.sourceRef, productId, newPMP: pmp })
                stock -= quantity;
                console.log("Stock after sale : " + stock);
            }
            else if (source === "sale_return") {
                updateDetail({ transaction, recordCollection: saleReturnCollection, currentLog, source, sourceRef: element.sourceRef, productId, newPMP: pmp })
                stock += quantity;
            }
            else if (source === "loss") {
                updateDetail({ transaction, recordCollection: lossCollection, currentLog, source, sourceRef: element.sourceRef, productId, newPMP: pmp })
                stock -= quantity;
            }
            else if (source === "inventory") {
                const docDetail = transaction.findRecordById(inventoryDetailCollection, element.sourceRef);
                const currentQuantityTheory = docDetail.get("quantityTheory");
                const currentQuantityInventiry = docDetail.get("quantityInventory");
                console.log("Stock before inventory : " + stock);
                docDetail.set("purchasePrice", pmp);
                docDetail.set("quantityTheory", stock);
                currentLog.set("quantity", currentQuantityInventiry - currentQuantityTheory);
                //currentLog.set("date", docDetail.get("date"));
                transaction.save(docDetail);
                //transaction.save(currentLog);
                stock += (currentQuantityInventiry - currentQuantityTheory);
                console.log("Stock after inventory : " + stock);
            }

        });
        try {
            const productRecalculateCollection = transaction.findCollectionByNameOrId("product_recalculate");
            const productRecalculate = transaction.findRecordById(productRecalculateCollection, productId);
            productRecalculate.set("status", 1);
            transaction.save(productRecalculate)
        }
        catch {

        }

    }
}