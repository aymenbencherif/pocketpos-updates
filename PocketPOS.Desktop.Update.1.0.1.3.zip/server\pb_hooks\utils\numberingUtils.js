module.exports = {

    generateEAN13: (prefix, counter) => {

        const data = `${prefix}${counter.toString().padStart(10, "0")}`;
        console.log(prefix);
        console.log(counter);
        console.log(data);
        if (data.length !== 12) {
            throw new Error("Counter must be between 0 and 9999999999");
        }

        let sum = 0;

        for (let i = 0; i < 12; i++) {
            const digit = Number(data[i]);
            sum += i % 2 === 0 ? digit : digit * 3;
        }

        const checkDigit = (10 - (sum % 10)) % 10;

        return data + checkDigit;
    }
}