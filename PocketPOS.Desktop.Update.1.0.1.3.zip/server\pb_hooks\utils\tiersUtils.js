/// <reference path="../../pb_data/types.d.ts" />s
module.exports = {

    updateTiersBalance: ({ transaction, tiersTableName, tiersId, purchase, payement }) => {
        var rows = transaction.db()
            .newQuery(`UPDATE ${tiersTableName} SET 
                purchase = purchase + {:purchase} ,
                payement = payement + {:payement} ,
                balance = balance + ({:purchase} - {:payement})
                WHERE id = {:tiersId}`)
            .bind({ purchase, payement, tiersId })
            .execute().rowsAffected();
        if (rows === 0)
            throw new BadRequestError("TIERS_NOT_FOUND");
    }
}