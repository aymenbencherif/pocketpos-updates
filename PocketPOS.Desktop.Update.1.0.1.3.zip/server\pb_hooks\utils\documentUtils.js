/// <reference path="../../pb_data/types.d.ts" />
module.exports = {


    getNextReference(transaction, tableName) {
        var record = transaction.findFirstRecordByFilter("numbering", `tableName = {:tableName}`, { tableName: tableName });
        var currentValue = record.get("nextValue");
        currentValue++;
        record.set("nextValue", currentValue);
        transaction.save(record);
        return currentValue.toString().padStart(7, '0')
    },
    updateDocumentFromDetail: (transaction, record, operation) => {

        const documentId = record.get("documentId");
        const purchasePrice = record.get("purchasePrice");
        const priceUET = record.get("priceUET");
        const discount = record.get("discount") ?? 0;
        const tax = record.get("tax") ?? 0;
        const priceUIT = priceUET * (1 + tax / 100);
        const priceEH = priceUET * (1 - discount / 100);
        const priceIT = priceEH * (1 + tax / 100);

        record.set("priceUIT", priceUIT);
        record.set("priceET", priceEH);
        record.set("priceIT", priceIT);

        //transaction.save(record);
        let documentParentName = "";
        let quantity = record.get("quantity");
        let numberProducts = 0;

        let totalPurchases = purchasePrice * quantity;
        let amountET = priceUET * quantity;
        let remiseET = (priceUET - priceEH) * quantity;
        let totalTaxes = (priceIT - priceEH) * quantity;
        let amountIT = priceIT * quantity;
        let netToPay = amountIT;

        switch (record.tableName()) {
            case "sale_delivery_detail":
                documentParentName = "sale_delivery";
                break;
            case "sale_return_detail":
                documentParentName = "sale_return";
                break;
            case "purchase_reception_detail":
                documentParentName = "purchase_reception";
                break;
            default:
                throw new Error(`Unknown table name: ${record.tableName()}`);
        }

        if (operation === "add") {
            numberProducts = 1;
        }

        else if (operation === "update") {

            const old_priceUET = record.original()?.get("priceUET") ?? 0;
            const old_discount = record.original()?.get("discount") ?? 0;
            const old_tax = record.original()?.get("tax") ?? 0;
            const old_priceUIT = record.original()?.get("priceUIT") ?? 0;
            const old_priceET = record.original()?.get("priceET") ?? 0;
            const old_priceIT = record.original()?.get("priceIT") ?? 0;
            const old_quantity = record.original()?.get("quantity") ?? 0;
            const old_purchasePrice = record.original()?.get("purchasePrice");

            const old_totalPurchases = old_purchasePrice * old_quantity;
            const old_amountET = old_priceUET * old_quantity;
            const old_remiseET = (old_priceUET - old_priceET) * old_quantity;
            const old_totalTaxes = (old_priceIT - old_priceET) * old_quantity;
            const old_amountIT = old_priceIT * old_quantity;
            const old_netToPay = old_amountIT;

            totalPurchases = totalPurchases - old_totalPurchases;
            quantity = quantity - old_quantity
            amountET = amountET - old_amountET;
            remiseET = remiseET - old_remiseET;
            totalTaxes = totalTaxes - old_totalTaxes;
            amountIT = amountIT - old_amountIT;
            netToPay = netToPay - old_netToPay;
            numberProducts = 0;
        }

        else if (operation === "delete") {
            totalPurchases = -totalPurchases;
            quantity = -quantity;
            amountET = -amountET;
            remiseET = -remiseET;
            totalTaxes = -totalTaxes;
            amountIT = -amountIT
            netToPay = -netToPay;
            numberProducts = -1;
        }

        else
            throw new Error(`Unknown operation: ${operation}`);

        // Update document informations stock
        let query = `
                UPDATE ${documentParentName} SET 
                numberProducts = numberProducts + {:numberProducts},
                tolalQuantities = tolalQuantities + {:quantity},
                amountET = amountET + {:amountET} ,
                remiseET = remiseET + {:remiseET} ,
                totalTaxes = totalTaxes + {:totalTaxes} ,
                amountIT = amountIT + {:amountIT} ,
                netToPay = netToPay + {:netToPay} ##CUSTIOM_QUERY##
                WHERE id = {:documentId} AND isValidated = 0;
            `;
        if (["sale_delivery_detail", "sale_return_detail"].includes("sale_delivery_detail")) {
            var subQuery = `, totalPurchases = totalPurchases + {:totalPurchases}`;
            query = query.replace("##CUSTIOM_QUERY##", subQuery);
        }
        query = query.replace("##CUSTIOM_QUERY##", "");
        var rows = transaction.db()
            .newQuery(query)
            .bind({ quantity, numberProducts, amountET, amountET, remiseET, totalTaxes, amountIT, netToPay, documentId, totalPurchases })
            .execute().rowsAffected();
        if (rows === 0) {
            let message = "";
            try {
                transaction.findRecordById(documentParentName, documentId);
                message = "DOCUMENT_IS_VALIDATED";
            }
            catch (ex) {
                message = "DOCUMENT_NOT_FOUNDD";
            }
            throw new BadRequestError(message);
        }
    },
    validateWithTiersLogIfCan(transaction, record) {
        const sourceUtils = require(`${__hooks}/utils/sourceUtils.js`);
        const dateUtiles = require(`${__hooks}/utils/dateUtils.js`);
        const dateTimeUtils = require(`${__hooks}/utils/daytimeUtils.js`);
        const source = sourceUtils.getSourceFromTableName(record.tableName());

        if (source !== "sale" && source !== "purchase" && source !== "sale_return")
            return;

        const isValidating = record.get("isValidated");
        const wasValidating = record.original()?.get("isValidated");

        if (isValidating === wasValidating)
            return;

        let payement = record.get("payement");
        const purchase = record.get("netToPay");

        const tiersId = record.get("tiersId");
        let date = record.get("date");
        const id = record.get("id");
        const payementMethodId = record.get("payementMethodId");
        const cashRegisterId = record.get("cashRegisterId");
        const sessionId = record.get("sessionId");
        const dateValidation = record.get("dateValidation");
        const formattedDate = dateTimeUtils.getFormatedDateTime(date);;
        const tiersTableName = ["sale_delivery", "sale_return"].includes(record.tableName()) ? "customer" : "provider";
        const payementMethod = transaction.findRecordById("payementMethod", payementMethodId);
        if (isValidating === true) {
            if (String(dateValidation) === "") {
                date = dateUtiles.getCurrentLocalDate(new Date());
                record.set("dateValidation", date);
                record.set("date", date);
            }
            if (tiersId) {
                if (payementMethod.get("type") == "term") {
                    payement = 0;
                    record.set("payement", 0);
                    record.set("newBalance", record.get("oldBalance") + purchase);
                }
                else {
                    record.set("newBalance", record.get("oldBalance") + purchase - payement);
                }
                const logCollection = transaction.findCollectionByNameOrId(`${tiersTableName}Log`);
                const logRecord = new Record(logCollection, {
                    "date": date,
                    "tiersId": tiersId,
                    "source": source,
                    "sourceRef": id,
                    "purchase": purchase,
                    "payement": payement,
                    "payementMethodId": payementMethodId,
                    "cashRegisterId": cashRegisterId,
                    "sessionId": sessionId
                });
                transaction.save(logRecord);
            }
            else {
                record.set("oldBalance", 0);
                record.set("newBalance", 0);
                const logCollection = transaction.findCollectionByNameOrId(`walking${tiersTableName}Log`);
                const logRecord = new Record(logCollection, {
                    "date": date,
                    "source": source,
                    "sourceRef": id,
                    "purchase": purchase,
                    "payement": payement,
                    "payementMethodId": payementMethodId,
                    "cashRegisterId": cashRegisterId,
                    "sessionId": sessionId
                });
                transaction.save(logRecord);
            }

        }
        else if (isValidating === false) {

            if (tiersId) {
                const collection = transaction.findCollectionByNameOrId(`${tiersTableName}Log`);
                transaction.delete(transaction.findRecordsByFilter(collection, `source="${source}" && sourceRef="${id}"`)[0]);
            }
            else {
                const collection = transaction.findCollectionByNameOrId(`walking${tiersTableName}Log`);
                transaction.delete(transaction.findRecordsByFilter(collection, `source="${source}" && sourceRef="${id}"`)[0]);
            }
        }
    },

}