/// <reference path="../../pb_data/types.d.ts" />s
module.exports = {
    setDetailPurchasePrice: (transaction, record) => {
        const sourceUtils = require(`${__hooks}/utils/sourceUtils.js`);
        const productCollection = transaction.findCollectionByNameOrId("product");
        const source = sourceUtils.getSourceFromTableName(record.tableName());
        const productId = record.get("productId");
        const product = transaction.findRecordById(productCollection, productId);
        const destockType = product.get("destockType");

        record.set("destockType", destockType);
        if (destockType === "destockable") {
            const purchasePrice = product.get("purchasePrice");
            record.set("purchasePrice", purchasePrice);
        }
        else if (destockType === "service") {
            record.set("purchasePrice", 0);
        }
        else if (destockType === "destock_another") {

            //destockProductid
            const destockProductId = product.get("destockProductId");
            const destockQuantity = product.get("destockQuantity");
            const linkedProduct = transaction.findRecordById(productCollection, destockProductId);
            const purchasePrice = linkedProduct.get("purchasePrice");

            record.set("destockProductId", destockProductId);
            record.set("destockQuantity", destockQuantity);
            record.set("purchasePrice", purchasePrice * destockQuantity);
        }
        else if (destockType === "composed") {

            let purchasePrice = 0;
            var composedProducts = transaction.findRecordsByFilter("productCompose", `productId = "${productId}"`);

            composedProducts.forEach(cp => {
                const productToDestock = transaction.findRecordById(productCollection, cp.get("productToDestockId"));
                const collection = transaction.findCollectionByNameOrId("productComposingTracking");
                const trackingCompose = new Record(collection, {
                    source: source,
                    sourceRef: record.get("id"),
                    productId: cp.get("productId"),
                    productToDestockId: cp.get("productToDestockId"),
                    quantity: cp.get("quantity")
                });
                transaction.save(trackingCompose);
                purchasePrice += productToDestock.get("purchasePrice") * cp.get("quantity");
            });
            record.set("purchasePrice", purchasePrice);
        }
        else
            throw new BadRequestError(`INVALID_PRODUCT_TYPE - ${destockType}`);
        transaction.save(record);

    },
    getPurtchasePriceAndDestockType: (transaction, productId) => {
        const destockUtils = require(`${__hooks}/utils/destockUtils.js`);
        const productCollection = transaction.findCollectionByNameOrId("product");
        const product = transaction.findRecordById(productCollection, productId);
        if (product.get("isDivers") === true) {
            return { purchasePrice: 0, destockType: "destockable" }
        }
        let destockType = product.get("destockType");
        let purchasePrice = 0;

        if (destockType === "destockable") {
            purchasePrice = product.get("purchasePrice");

        }
        else if (destockType === "service") {
            purchasePrice = 0;
        }
        else if (destockType === "destock_another") {

            const destockProductId = product.get("destockProductId");
            const destockQuantity = product.get("destockQuantity");
            const destockPurchasePrice = destockUtils.getPurtchasePriceAndDestockType(transaction, destockProductId).purchasePrice;
            purchasePrice = destockQuantity * destockPurchasePrice;
        }
        else if (destockType === "composed") {

            var composedProducts = transaction.findRecordsByFilter("productCompose", `productId = "${productId}"`);

            composedProducts.forEach(cp => {
                console.log(cp.get("id"));
                const destockQuantity = cp.get("quantity");
                const destockProductId = cp.get("productToDestockId");
                purchasePrice += destockQuantity * destockUtils.getPurtchasePriceAndDestockType(transaction, destockProductId).purchasePrice;
            });
        }
        else
            throw new BadRequestError(`INVALID_PRODUCT_TYPE - ${destockType}`);

        return {
            purchasePrice,
            destockType
        }

    }
}